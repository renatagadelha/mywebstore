<nav class="navbar">
    <div class="container">
        <a class="navbar-brand">My Web Store</a>

        <!-- <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="../../index.html">
                    <img src="assets/img/icon-login.svg" class="icon icon-login">
                    Olá, Carol
                </a>
            </li>
        </ul> -->
    </div>
</nav>