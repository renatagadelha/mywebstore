<link rel="stylesheet" href="./views/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="./views/assets/css/style.css">